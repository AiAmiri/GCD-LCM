import java.util.Scanner;
public class GreatestCommonDivider {
	public static void main(String[] args) {
	Scanner input = new Scanner (System.in);
	System.out.println("Welcome to GCD calculator ");
	System.out.print("enter first number : ");
	long num1=input.nextLong();
	System.out.print("enter second number : ");
	long num2=input.nextLong();
	long min=Math.min(num1,num2);
	boolean res = !(num1%min==0 && num2%min==0);
    while (res && min>1){
    min--;
    }
    System.out.println("GCD is = "+ min);
	System.out.println("LCM IS = "+ num1*num2/min);
 }
}